#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>


#define LIGHT_PIN    A0
#define DHT_PIN      2
#define LIGHT_RELAY  8


#define LIGHT_THRESHOLD  700


#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

DHT dht(DHT_PIN, DHT22);

void setup() {
  Serial.begin(9600);
  
 
  pinMode(LIGHT_RELAY, OUTPUT);
  digitalWrite(LIGHT_RELAY, LOW);

 
  dht.begin();

 
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
}

void loop() {
 
  int lightVal = analogRead(LIGHT_PIN);
  float temp  = dht.readTemperature();
  float humi  = dht.readHumidity();

  
  if (lightVal > LIGHT_THRESHOLD) {
    digitalWrite(LIGHT_RELAY, HIGH); // 开灯
  } else {
    digitalWrite(LIGHT_RELAY, LOW);  // 关灯
  }

  // OLED 屏幕显示
  display.clearDisplay();
  
  display.setCursor(0, 0);
  display.print("Light: ");
  display.print(lightVal);

  display.setCursor(0, 16);
  display.print("Temp:  ");
  display.print(temp);
  display.print(" C");

  display.setCursor(0, 32);
  display.print("Humi:  ");
  display.print(humi);
  display.print(" %");

  display.setCursor(0, 48);
  display.print("LED: ");
  display.print(digitalRead(LIGHT_RELAY) ? "ON" : "OFF");

  display.display();
  delay(1000);
}